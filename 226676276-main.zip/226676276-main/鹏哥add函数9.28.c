int add(int x,int y)
{
    int z = 0;
    z = x + y;
    return z;
}
//add：函数名 int：返回类型{函数体} (函数参数)
int add(int x,int y)
{
    return x + y;
}
//简化
int main(void)
{
    int sum = add(2,3);//函数调用操作符()
}
