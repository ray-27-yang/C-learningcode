//计算数组元素的个数
#include<stdio.h>

int main(void)
{          []:是数组的形式，里面只能是常数
    int arr[10] = {0};
    printf("%zu\n",sizeof(arr) / sizeof(arr[0]));
                                           []:下标引用操作符，arr和3就是它的操作数，可以放变量
    return 0;
}

//前缀与后缀++--
int a = 10;
int b = a++;//后缀；先使用后++
//int b = a;a = a + 1;
printf("%d",b);//10
printf("%d",a);//11
//后置的话这两个值都是11

//强制类型转换：int a = (int)3.14; printf为3

//三目操作符
int a = 10;
int b = 20;
int r = a > b ? a : b;//b20

//逗号表达式就是逗号隔开的一串表达式
//特点是从左向右依次计算，整个表达式的结果是最后一个表达式的结果

